/* Original character-driven boarding simulation, with fixed-step replay for video export. */
(() => {
'use strict';
const A=window.MetroArt,canvas=document.getElementById('art'),ctx=canvas.getContext('2d',{alpha:false});
const DT=1/60,TAU=Math.PI*2,FLOOR=205;
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),lerp=(a,b,t)=>a+(b-a)*t;
const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
const specs=[
 {name:'橙衣上班族',color:'#ff853d',h:186,w:110,skin:'#f3bd94',hair:0,prop:'case'},
 {name:'巨包学生',color:'#397afa',h:177,w:118,skin:'#dca27d',hair:1,prop:'backpack'},
 {name:'咖啡通勤客',color:'#ed549e',h:177,w:108,skin:'#f1c0a3',hair:2,prop:'coffee'},
 {name:'长伞先生',color:'#2caf7d',h:194,w:116,skin:'#b67b59',hair:3,prop:'umbrella'},
 {name:'耳机乘客',color:'#9567e8',h:166,w:108,skin:'#edb993',hair:4,prop:'headphones'},
 {name:'羽绒服大叔',color:'#f4c838',h:184,w:148,skin:'#dba681',hair:5,prop:'plant'},
 {name:'行李箱乘客',color:'#35bbd0',h:174,w:110,skin:'#a87658',hair:6,prop:'suitcase'},
 {name:'最后一只鞋',color:'#f36958',h:162,w:104,skin:'#f1bf9d',hair:7,prop:'scarf'}
];
let sim,silent=true;
function random(s,a=0,b=1){s.seed=(Math.imul(s.seed,1664525)+1013904223)>>>0;return lerp(a,b,s.seed/4294967296)}
function passengers(){return specs.map((v,id)=>({...v,id,x:930,tx:88+112*id,vx:0,y:0,vy:0,mode:'queue',age:0,walk:0,sx:1,sv:0,sy:1,lean:0,lv:0,shock:0,bagFold:0,flags:new Set(),face:'normal',arrived:false,hand:0}))}
function make(){return{seed:1927,time:0,elapsed:0,age:0,phase:'boarding',cycles:0,people:passengers(),count:0,progress:0,pv:0,target:0,active:-1,delay:.7,auto:true,press:false,pressTime:0,hover:-1,waves:[],parts:[],objects:[],audio:[],cup:null,lid:null,suitcase:null,shoe:null,shoeless:false,shoeHelp:0,door:1,doorBlink:0,trainX:0,trainV:0,trainTilt:0,flash:0,shake:0,warp:{p:0,v:0},flags:new Set(),labelPulse:0}}
function sound(s,kind,volume=1){s.audio.push({t:s.elapsed,kind,volume});if(s===sim&&!silent)Sfx.play(kind,volume)}
function wave(s,id,amp=1){s.waves.push({id,amp,t:0})}
function emit(s,kind,x,y,n=8,power=100){for(let i=0;i<n;i++)s.parts.push({kind,x,y,vx:random(s,-power,power),vy:random(s,-power*1.6,-10),life:random(s,.3,1.1),rot:random(s,-3,3),spin:random(s,-9,9),size:random(s,2,4),color:['#ffd748','#347bff','#ef629c','#40bb9c'][i%4]})}
function phase(s,name){s.phase=name;s.age=0;s.flags.clear()}
function once(s,key,fn){if(!s.flags.has(key)){s.flags.add(key);fn()}}
function spawn(s){const id=s.count;if(id>=8)return;const a=s.people[id];a.x=930;a.vx=-20;a.age=0;a.mode=id===1?'bagjam':'enter';s.active=id;s.delay=.3;sound(s,'step',.4);if(id===1){sound(s,'squeak',.8);a.shock=.8;phase(s,'bagjam')}}
function arrive(s,a){
 a.mode='boarded';a.arrived=true;a.vx=0;s.count++;s.active=-1;s.delay=.3;s.target=s.count===8?.99:s.count/8;s.labelPulse=1;wave(s,a.id,.42);sound(s,'settle',.7);
 if(a.id===3){phase(s,'umbrella');sound(s,'umbrella',.8)}
 else if(a.id===5){phase(s,'coat');sound(s,'squish',.8)}
 else if(a.id===6){s.suitcase={x:a.x+55,y:FLOOR,vx:145,mode:'rolling',angle:0};sound(s,'wheel',.5)}
 else if(a.id===7){phase(s,'shoe');s.doorBlink=1;s.shoeHelp=0;s.shoeless=false;for(const p of s.people)p.shock=.6;sound(s,'bell',.7)}
}
function releaseShoe(s){
 phase(s,'success');s.target=1;s.progress=1;s.pv=0;s.flash=1;s.labelPulse=1;s.shake=2;s.warp.v=.6;s.shoeless=true;
 s.shoe={x:941,y:194,vx:-155,vy:-320,age:0,angle:-.35};wave(s,7,1.25);emit(s,'star',920,168,13,140);sound(s,'shoe',1);sound(s,'complete',.8);
}
function poke(s,id=7){
 const p=s.people[clamp(Math.round(id),0,7)];p.shock=.85;wave(s,p.id,.95);s.warp.v+=.3;s.shake=Math.max(s.shake,1.4);emit(s,'star',p.x,90,5,65);sound(s,'squeak',.6);
 if(s.phase==='shoe'){s.shoeHelp++;if(s.suitcase)s.suitcase.vx=-210}
}
function updatePerson(s,a,dt){
 a.age+=dt;a.shock=Math.max(0,a.shock-dt);if(a.mode==='queue')return;
 let force=0,leanTarget=0,compression=0;
 for(const w of s.waves){const q=w.t-Math.abs(a.id-w.id)*.075;if(q>0&&q<1.1){const v=w.amp*Math.exp(-q*4)*Math.sin(q*24);force+=v*20;leanTarget+=v*.17;compression+=Math.abs(v)*.14}}
 if(a.mode==='bagjam'){a.x=920+Math.sin(a.age*19)*3;a.bagFold=ease((s.age-1.35)/.55);a.lean=Math.sin(a.age*12)*.08;a.sx=1-Math.max(0,Math.sin(a.age*8))*.07;if(s.age>2.05){a.mode='enter';a.vx=-80;a.bagFold=1;phase(s,'boarding');wave(s,1,1.1);sound(s,'pop',.8)}return}
 if(a.mode==='juggle'){a.vx*=.7;leanTarget=Math.sin(a.age*8)*.12;if(s.age>1.35){a.mode='enter';s.cup=null;s.lid=null;phase(s,'boarding');a.shock=.25;sound(s,'catch',.8)}}
 if(a.mode==='enter'){
   const diff=a.tx-a.x;a.vx+=((diff)*28-a.vx*10)*dt;a.vx=clamp(a.vx,-440,350);a.x+=a.vx*dt;a.walk+=Math.abs(a.vx)*dt*.052;
   leanTarget=clamp(a.vx/2100,-.16,.12);a.y=-Math.abs(Math.sin(a.walk))*4;
   if(a.id===2&&a.x<430&&!a.flags.has('coffee')){a.flags.add('coffee');a.mode='juggle';a.vx=0;a.age=0;phase(s,'coffee');s.cup={x:a.x-44,y:110,x0:a.x-44,y0:110,age:0,vx:-58,vy:-290};s.lid={x:a.x-42,y:108,vx:45,vy:-315,angle:0};a.shock=1.3;s.people[1].shock=.8;wave(s,1,1);emit(s,'coffee',a.x-44,109,7,85);sound(s,'coffee',.9)}
   if(a.mode==='enter'&&Math.abs(a.x-a.tx)<5&&Math.abs(a.vx)<30)arrive(s,a);
 }else if(a.mode==='boarded'){
   let target=a.tx+force;
   if(s.phase==='coat'&&Math.abs(a.id-5)<=2)compression+=Math.abs(Math.sin(s.age*5))*.12;
   if(s.phase==='umbrella'&&a.id<4){const opening=ease(s.age/.35)*(1-ease((s.age-1.8)/.5));target+=(a.id<3?-1:1)*opening*(a.id===2?15:7);compression+=opening*.18;leanTarget+=(a.id<3?-.12:.14)*opening}
   if(s.phase==='shoe'){
    if(a.id===7){target-=Math.sin(s.age*9)*3;leanTarget=-.16;compression+=.07}
    else{leanTarget=.11;compression+=.045;target+=Math.sin(s.age*7-a.id)*5}
   }
   if(s.phase==='success'){leanTarget=-.04+Math.sin(s.age*6+a.id)*.025;a.y=-Math.max(0,Math.sin(s.age*9-a.id*.4))*4}
   else if(s.phase==='depart')leanTarget=-.23;
   a.vx+=((target-a.x)*90-a.vx*17)*dt;a.x+=a.vx*dt;a.y+=(0-a.y)*Math.min(1,dt*9);
   for(const b of s.people){if(b.id<=a.id||b.mode!=='boarded')continue;const d=b.x-a.x,pen=(a.w+b.w)*.5+7-d;if(pen>0&&d>0){compression+=Math.min(.18,pen/100);a.x-=pen*dt*1.3;b.x+=pen*dt*1.3}}
 }
 if(s.phase==='depart')a.y-=Math.abs(Math.sin(s.time*29+a.id))*.45;
 const sxTarget=1-clamp(compression,0,.3)+(a.shock>0?Math.sin(a.shock*25)*.03:0);
 a.sv+=((sxTarget-a.sx)*170-a.sv*14)*dt;a.sx=clamp(a.sx+a.sv*dt,.65,1.12);a.sy=1/Math.pow(a.sx,.34);
 a.lv+=((leanTarget-a.lean)*130-a.lv*15)*dt;a.lean+=a.lv*dt;
}
function advance(s,dt){
 s.time+=dt;s.elapsed+=dt;s.age+=dt;s.flash*=Math.exp(-dt*4);s.shake*=Math.exp(-dt*8);s.labelPulse*=Math.exp(-dt*5);s.doorBlink=Math.max(0,s.doorBlink-dt*.2);
 s.warp.v+=((s.press?.035:0)-s.warp.p)*240*dt-s.warp.v*13*dt;s.warp.p+=s.warp.v*dt;
 s.pv+=((s.target-s.progress)*90-s.pv*18)*dt;s.progress=clamp(s.progress+s.pv*dt,0,s.target);
 if(s.phase==='boarding'){
   if(s.active<0){s.delay-=dt;if(s.delay<=0&&s.count<8)spawn(s)}
 }else if(s.phase==='umbrella'){
   if(s.age>.25)once(s,'open',()=>{wave(s,3,1.3);emit(s,'star',426,30,6,80);sound(s,'boing',.9)});
   if(s.age>1.85)once(s,'fold',()=>{wave(s,3,.9);sound(s,'snap',.75)});
   if(s.age>2.45){phase(s,'boarding');s.delay=.25}
 }else if(s.phase==='coat'){
   if(s.age>.7)once(s,'sneeze',()=>{emit(s,'leaf',555,61,7,90);wave(s,5,1.1);s.people[4].shock=.8;sound(s,'sneeze',.7)});
   if(s.age>1.55){phase(s,'boarding');s.delay=.25}
 }else if(s.phase==='shoe'){
   if(s.age>.6)once(s,'push1',()=>{wave(s,0,.85);sound(s,'heave',.6)});
   if(s.age>1.6)once(s,'push2',()=>{wave(s,0,1.3);sound(s,'heave',.8)});
   if(s.age>1&&s.suitcase){s.suitcase.mode='pulling';s.suitcase.vx+=( -145-s.suitcase.vx)*Math.min(1,dt*8)}
   if(s.suitcase&&s.suitcase.x<845&&((s.auto&&s.age>2.6)||s.shoeHelp>0))releaseShoe(s);
 }else if(s.phase==='success'){
   s.door=1-ease((s.age-.25)/.65);if(s.age>.3)once(s,'doors',()=>sound(s,'doors',.8));
   if(s.age>1.6){phase(s,'depart');s.trainV=0;sound(s,'train',.7)}
 }else if(s.phase==='depart'){
   s.trainV+=1120*dt;s.trainX+=s.trainV*dt;
   if(s.trainX>1440){phase(s,'return');s.people=passengers();s.count=0;s.progress=0;s.pv=0;s.target=0;s.active=-1;s.trainX=-1440;s.trainV=0;s.door=1;s.suitcase=null;s.shoe=null;s.shoeless=false;s.parts=[];s.waves=[]}
 }else if(s.phase==='return'){
   s.trainV+=(-s.trainX*38-s.trainV*12)*dt;s.trainX+=s.trainV*dt;
   if(Math.abs(s.trainX)<.3&&Math.abs(s.trainV)<2){const old={elapsed:s.elapsed,cycles:s.cycles+1,audio:s.audio,auto:s.auto};Object.assign(s,make(),old)}
 }
 for(const a of s.people)updatePerson(s,a,dt);
 if(s.cup){const o=s.cup;o.age+=dt;if(o.age<.75){o.vy+=620*dt;o.x+=o.vx*dt;o.y+=o.vy*dt}else{const p=clamp((o.age-.75)/.58);o.x=lerp(o.x,s.people[2].x-44,p*.3);o.y=lerp(o.y,112,p*.3)}if(s.lid){s.lid.vy+=620*dt;s.lid.x+=s.lid.vx*dt;s.lid.y+=s.lid.vy*dt;s.lid.angle+=dt*15}}
 if(s.suitcase){const o=s.suitcase;o.x+=o.vx*dt;o.angle+=o.vx*dt*.025;if(o.mode==='rolling'&&o.x>=912){o.x=912;o.vx=0;o.mode='parked';sound(s,'bump',.5)}if(o.mode==='pulling'&&o.x<=813){o.x=813;o.vx=0}}
 if(s.shoe){const o=s.shoe;o.age+=dt;o.vy+=620*dt;o.x+=o.vx*dt;o.y+=o.vy*dt;o.angle+=dt*10;if(o.age>1.05){s.shoe=null;s.shoeless=false;sound(s,'catch',.7)}}
 for(let i=s.waves.length-1;i>=0;i--){s.waves[i].t+=dt;if(s.waves[i].t>2.2)s.waves.splice(i,1)}
 for(let i=s.parts.length-1;i>=0;i--){const p=s.parts[i];p.life-=dt;if(p.life<=0){s.parts.splice(i,1);continue}p.vy+=(p.kind==='note'?-80:550)*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.rot+=p.spin*dt}
}
const Sfx=(()=>{let ac=null,on=false;return{get on(){return on},toggle(){on=!on;if(on&&!ac)ac=new AudioContext();if(ac?.state==='suspended')ac.resume();return on},play(kind,v=1){if(!ac||!on)return;const sounds={step:[135,.045],settle:[250,.1],squeak:[600,.13],pop:[320,.12],coffee:[780,.2],catch:[440,.08],umbrella:[190,.2],boing:[160,.3],snap:[1000,.05],squish:[220,.2],sneeze:[450,.18],wheel:[140,.1],bell:[1050,.16],heave:[180,.16],shoe:[260,.2],complete:[880,.65],doors:[700,.16],train:[90,.6],bump:[120,.09]};let[f,d]=sounds[kind]||[300,.1];const o=ac.createOscillator(),g=ac.createGain(),t=ac.currentTime;o.type=kind==='bell'?'triangle':'sine';o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(Math.max(35,f*(kind==='boing'?2.5:.55)),t+d);g.gain.setValueAtTime(.055*v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+d)}}})();
const measured=make();let frames=0;while(!measured.cycles&&frames<6000){advance(measured,DT);frames++}if(!measured.cycles)throw Error('Boarding simulation did not complete');const duration=frames/60,eventLog=measured.audio.slice();
sim=make();silent=false;
function render(){ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#fafbfc';ctx.fillRect(0,0,1080,1440);A.render(ctx,sim)}
let playing=!new URLSearchParams(location.search).has('capture'),last=performance.now(),acc=0;
function raf(now){const dt=Math.min(.05,(now-last)/1000);last=now;if(playing){sim.pressTime=sim.press?sim.pressTime+dt:0;acc+=dt*(sim.pressTime>.25?3:1);while(acc>=DT){advance(sim,DT);acc-=DT}render()}requestAnimationFrame(raf)}
function point(e){const r=canvas.getBoundingClientRect();return[(e.clientX-r.left)/r.width*1080,(e.clientY-r.top)/r.height*1440]}
canvas.addEventListener('pointerdown',e=>{const[x,y]=point(e);if(x>35&&x<1045&&y>596&&y<900){sim.press=true;const world=x-60-sim.trainX;let found=sim.people.filter(a=>a.mode!=='queue').sort((a,b)=>Math.abs(a.x-world)-Math.abs(b.x-world))[0];poke(sim,found?.id??7);canvas.setPointerCapture(e.pointerId);render()}});
canvas.addEventListener('pointerup',()=>sim.press=false);canvas.addEventListener('pointercancel',()=>sim.press=false);canvas.addEventListener('pointerleave',()=>sim.press=false);
canvas.addEventListener('keydown',e=>{if(e.key===' '){e.preventDefault();playing=!playing;document.getElementById('play').textContent=playing?'暂停':'播放'}if(e.key==='Enter')poke(sim)});
document.getElementById('play').onclick=()=>{playing=!playing;document.getElementById('play').textContent=playing?'暂停':'播放'};
document.getElementById('reset').onclick=()=>{sim=make();acc=0;playing=true;document.getElementById('play').textContent='暂停';document.getElementById('auto').textContent='自动演绎：开';render()};
document.getElementById('auto').onclick=()=>{sim.auto=!sim.auto;document.getElementById('auto').textContent='自动演绎：'+(sim.auto?'开':'关')};
document.getElementById('sound').onclick=()=>{document.getElementById('sound').textContent='音效：'+(Sfx.toggle()?'开':'关')};
document.getElementById('save').onclick=()=>{const a=document.createElement('a');a.href=canvas.toDataURL('image/png');a.download='全员挤进地铁_1080x1440.png';a.click()};
if(!playing){document.body.classList.add('capture');document.getElementById('play').textContent='播放'}
window.metroEngine={width:1080,height:1440,duration,frames,eventLog,specs,
 reset(){playing=false;silent=true;sim=make();render()},advance(n=1){for(let i=0;i<n;i++)advance(sim,DT);render()},renderAt(t){playing=false;silent=true;sim=make();for(let i=0;i<Math.floor(t*60);i++)advance(sim,DT);render();return this.state},resume(){playing=true;silent=false},pause(){playing=false},poke(id){poke(sim,id);render()},get state(){return{time:sim.time,phase:sim.phase,boarded:sim.count,percent:Math.round(sim.target*100),people:sim.people.map(a=>({name:a.name,mode:a.mode,x:a.x,sx:a.sx})),cycles:sim.cycles}},get sim(){return sim}};
render();requestAnimationFrame(raf);
})();
